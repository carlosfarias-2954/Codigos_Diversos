"""Servidor web do OpenShelf: liga a interface HTML (index.html) ao banco MySQL.

Usa o banco.py (mesmas funções do CRUD do terminal). Só precisa do mysql-connector-python.
Execute:  python servidor.py   e abra  http://localhost:8000
"""
import json
import threading
import traceback
import webbrowser
from contextlib import closing
from decimal import Decimal, InvalidOperation
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import banco
from banco import Error, IntegrityError

PASTA = Path(__file__).parent
PORTA = 8000
RECURSOS = {"generos": "genero", "editoras": "editora"}


class Recusa(Exception):
    """Erro de validação ou regra de negócio, devolvido ao navegador com o código HTTP."""

    def __init__(self, mensagem, status=400):
        super().__init__(mensagem)
        self.status = status


# ---------- validação ----------
def inteiro(valor, rotulo, minimo, maximo, opcional=False):
    if valor in (None, ""):
        if opcional:
            return None
        raise Recusa(f"{rotulo} é obrigatório.")
    try:
        n = int(str(valor).strip())
    except ValueError:
        raise Recusa(f"{rotulo} inválido.")
    if not minimo <= n <= maximo:
        raise Recusa(f"{rotulo} deve estar entre {minimo} e {maximo}.")
    return n


def texto(valor, rotulo, maximo):
    valor = str(valor or "").strip()
    if not valor:
        raise Recusa(f"{rotulo} é obrigatório.")
    if len(valor) > maximo:
        raise Recusa(f"{rotulo}: máximo de {maximo} caracteres.")
    return valor


def preco(valor):
    if valor in (None, ""):
        return None
    try:
        p = Decimal(str(valor).replace(",", ".")).quantize(Decimal("0.01"))
    except InvalidOperation:
        raise Recusa("Preço inválido.")
    if not 0 <= p < Decimal("10000000000"):
        raise Recusa("Preço fora do limite.")
    return p


def dados_livro(conn, d):
    """Valida o JSON de um livro e devolve (titulo, autor, ano, cd_editora, cd_genero, preco)."""
    cd_editora = inteiro(d.get("cd_editora"), "Editora", 1, 2**31 - 1)
    cd_genero = inteiro(d.get("cd_genero"), "Gênero", 1, 2**31 - 1)
    if not banco.buscar_simples(conn, "editora", cd_editora):
        raise Recusa("Editora não cadastrada.")
    if not banco.buscar_simples(conn, "genero", cd_genero):
        raise Recusa("Gênero não cadastrado.")
    return (texto(d.get("titulo"), "Título", 100), texto(d.get("autor"), "Autor", 50),
            inteiro(d.get("ano"), "Ano", 1000, 2100, opcional=True), cd_editora, cd_genero, preco(d.get("preco")))


def livro_json(l):
    return {"isbn": l[0], "titulo": l[1], "autor": l[2], "ano": l[3],
            "editora": l[4], "genero": l[5], "preco": l[6]}


# ---------- rotas da API ----------
def api_livros(conn, metodo, chave, consulta, corpo):
    if metodo == "GET":
        if chave is not None:
            raw = banco.buscar_livro(conn, inteiro(chave, "ISBN", 1, 9999999999999))
            if not raw:
                raise Recusa("Livro não encontrado.", 404)
            return dict(zip(("isbn", "titulo", "autor", "ano", "cd_editora", "cd_genero", "preco"), raw))
        q = consulta.get("q", [""])[0].strip()
        if q:
            linhas = banco.livros_por_texto(conn, q)
        elif consulta.get("genero", [""])[0]:
            linhas = banco.livros_por_genero(conn, int(consulta["genero"][0]))
        elif consulta.get("editora", [""])[0]:
            linhas = banco.livros_por_editora(conn, int(consulta["editora"][0]))
        else:
            linhas = banco.listar_livros(conn)
        return [livro_json(l) for l in linhas]
    if metodo == "POST":
        isbn = inteiro(corpo.get("isbn"), "ISBN", 1, 9999999999999)
        if banco.buscar_livro(conn, isbn):
            raise Recusa("Já existe um livro com esse ISBN.", 409)
        banco.incluir_livro(conn, isbn, *dados_livro(conn, corpo))
        return {"mensagem": "Livro incluído."}
    isbn = inteiro(chave, "ISBN", 1, 9999999999999)
    if not banco.buscar_livro(conn, isbn):
        raise Recusa("Livro não encontrado.", 404)
    if metodo == "PUT":
        banco.alterar_livro(conn, isbn, *dados_livro(conn, corpo))
        return {"mensagem": "Livro alterado."}
    banco.excluir_livro(conn, isbn)
    return {"mensagem": "Livro excluído."}


def api_simples(conn, tab, metodo, chave, consulta, corpo):
    nome_max = banco.TABELAS[tab][3]
    if metodo == "GET":
        q = consulta.get("q", [""])[0].strip()
        linhas = banco.buscar_simples_nome(conn, tab, q) if q else banco.listar_simples(conn, tab)
        return [{"codigo": c, "nome": n} for c, n in linhas]
    if metodo == "POST":
        codigo = banco.proximo_codigo(conn, tab)
        banco.incluir_simples(conn, tab, codigo, texto(corpo.get("nome"), "Nome", nome_max))
        return {"mensagem": "Registro incluído.", "codigo": codigo}
    codigo = inteiro(chave, "Código", 1, 2**31 - 1)
    if not banco.buscar_simples(conn, tab, codigo):
        raise Recusa("Registro não encontrado.", 404)
    if metodo == "PUT":
        banco.alterar_simples(conn, tab, codigo, texto(corpo.get("nome"), "Nome", nome_max))
        return {"mensagem": "Registro alterado."}
    try:
        banco.excluir_simples(conn, tab, codigo)
    except IntegrityError:
        raise Recusa("Não é possível excluir: existem livros vinculados a este registro.", 409)
    return {"mensagem": "Registro excluído."}


def tratar_api(metodo, caminho, consulta, corpo):
    partes = [p for p in caminho.split("/") if p][1:]
    if not partes or len(partes) > 2:
        raise Recusa("Rota não encontrada.", 404)
    recurso, chave = partes[0], (partes[1] if len(partes) > 1 else None)
    if metodo in ("PUT", "DELETE") and chave is None:
        raise Recusa("Informe o código do registro.")
    with closing(banco.conectar()) as conn:
        if recurso == "livros":
            return api_livros(conn, metodo, chave, consulta, corpo)
        if recurso in RECURSOS:
            return api_simples(conn, RECURSOS[recurso], metodo, chave, consulta, corpo)
    raise Recusa("Rota não encontrada.", 404)


# ---------- servidor HTTP ----------
class Handler(BaseHTTPRequestHandler):
    def responder(self, status, dados=None, bruto=None, tipo="application/json; charset=utf-8"):
        corpo = bruto if bruto is not None else json.dumps(dados, ensure_ascii=False, default=float).encode()
        self.send_response(status)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def tratar(self, metodo):
        url = urlparse(self.path)
        if metodo == "GET" and url.path in ("/", "/index.html"):
            return self.responder(200, bruto=(PASTA / "index.html").read_bytes(), tipo="text/html; charset=utf-8")
        if not url.path.startswith("/api/"):
            return self.responder(404, {"erro": "Página não encontrada."})
        try:
            tamanho = int(self.headers.get("Content-Length") or 0)
            corpo = json.loads(self.rfile.read(tamanho) or b"{}") if tamanho else {}
            self.responder(200, tratar_api(metodo, url.path, parse_qs(url.query), corpo))
        except Recusa as e:
            self.responder(e.status, {"erro": str(e)})
        except (ValueError, json.JSONDecodeError):
            self.responder(400, {"erro": "Dados inválidos."})
        except Error as e:
            self.responder(500, {"erro": f"Erro no banco de dados: {e}"})
        except Exception as e:  # qualquer outro erro: mostra no terminal e avisa a tela
            traceback.print_exc()
            self.responder(500, {"erro": f"Erro interno do servidor: {e}"})

    do_GET = lambda self: self.tratar("GET")
    do_POST = lambda self: self.tratar("POST")
    do_PUT = lambda self: self.tratar("PUT")
    do_DELETE = lambda self: self.tratar("DELETE")

    def log_message(self, formato, *args):
        pass


def main():
    try:
        banco.conectar().close()  # pede a senha, cria o banco se preciso e testa a conexão
    except Error as e:
        raise SystemExit(f"Não foi possível usar o MySQL: {e}\nConfira o servidor e o usuário/senha (DB_USER, DB_PASSWORD).")
    servidor = ThreadingHTTPServer(("127.0.0.1", PORTA), Handler)
    url = f"http://localhost:{PORTA}"
    print(f"OpenShelf no ar em {url}  (Ctrl+C para encerrar)")
    threading.Timer(1, lambda: webbrowser.open(url)).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrado.")


if __name__ == "__main__":
    main()
