from contextlib import closing
from decimal import Decimal, InvalidOperation

import banco
from banco import Error, IntegrityError


# ---------- entrada de dados ----------
def ler_texto(rotulo, atual=None, maximo=None):
    """Texto obrigatório. Em alteração, Enter mantém o valor atual."""
    while True:
        dica = f" [{atual}]" if atual else ""
        valor = input(f"{rotulo}{dica}: ").strip()
        if not valor:
            if atual:
                return atual
            print("  Campo obrigatório.")
        elif maximo and len(valor) > maximo:
            print(f"  Máximo de {maximo} caracteres.")
        else:
            return valor


def ler_numero(rotulo, atual=None, minimo=0, maximo=None, opcional=False):
    while True:
        dica = f" [{atual}]" if atual is not None else ""
        valor = input(f"{rotulo}{dica}: ").strip()
        if not valor:
            if atual is not None or opcional:
                return atual
            print("  Campo obrigatório.")
        elif valor.isdigit() and int(valor) >= minimo and (maximo is None or int(valor) <= maximo):
            return int(valor)
        else:
            print("  Valor inválido.")


def ler_preco(atual=None):
    while True:
        dica = f" [{atual}]" if atual is not None else ""
        valor = input(f"Preço (opcional){dica}: ").strip().replace(",", ".")
        if not valor:
            return atual
        try:
            preco = Decimal(valor).quantize(Decimal("0.01"))
            if 0 <= preco < Decimal("10000000000"):
                return preco
        except InvalidOperation:
            pass
        print("  Digite um preço válido (ex.: 59,90).")


def escolher_codigo(conn, tab, rotulo, atual=None):
    """Mostra os registros de gênero/editora e pede um código existente."""
    registros = banco.listar_simples(conn, tab)
    if not registros:
        print(f"  Cadastre antes ao menos uma {rotulo.lower()}.")
        return None
    validos = {r[0] for r in registros}
    for cod, nome in sorted(registros):
        print(f"  {cod}. {nome}")
    while True:
        cod = ler_numero(f"Código ({rotulo.lower()})", atual, minimo=1)
        if cod in validos:
            return cod
        print("  Código não cadastrado.")

def mostrar_livros(livros):
    if not livros:
        print("  Nenhum livro encontrado.")
        return
    print(f"\n{'ISBN':<14}{'Título':<33}{'Autor':<22}{'Ano':<6}{'Editora':<14}{'Gênero':<24}{'Preço':>9}")
    print("-" * 122)
    for isbn, titulo, autor, ano, editora, genero, preco in livros:
        p = f"{preco:.2f}" if preco is not None else "-"
        print(f"{isbn:<14}{(titulo or '')[:31]:<33}{(autor or '')[:20]:<22}{ano or '-':<6}"
              f"{(editora or '-')[:12]:<14}{(genero or '-')[:22]:<24}{p:>9}")
    print(f"\n{len(livros)} livro(s).")

def mostrar_simples(registros, rotulo):
    if not registros:
        print(f"  Nenhum registro encontrado em {rotulo}.")
        return
    print(f"\n{'Código':<8}{rotulo}\n" + "-" * 40)
    for cod, nome in registros:
        print(f"{cod:<8}{nome}")
    print(f"\n{len(registros)} registro(s).")

def incluir_livro(conn):
    print("\n== INCLUSÃO DE LIVRO ==")
    isbn = ler_numero("ISBN (até 13 dígitos)", minimo=1, maximo=9999999999999)
    if banco.buscar_livro(conn, isbn):
        print("Já existe um livro com esse ISBN.")
        return
    titulo = ler_texto("Título", maximo=100)
    autor = ler_texto("Autor", maximo=50)
    ano = ler_numero("Ano de publicação (opcional)", minimo=1000, maximo=2100, opcional=True)
    cd_editora = escolher_codigo(conn, "editora", "Editora")
    cd_genero = escolher_codigo(conn, "genero", "Gênero")
    if cd_editora is None or cd_genero is None:
        return
    preco = ler_preco()
    banco.incluir_livro(conn, isbn, titulo, autor, ano, cd_editora, cd_genero, preco)
    print("Livro incluído.")

def alterar_livro(conn):
    print("\n== ALTERAÇÃO DE LIVRO ==")
    livro = banco.buscar_livro(conn, ler_numero("ISBN do livro", minimo=1))
    if not livro:
        print("Livro não encontrado.")
        return
    isbn, titulo, autor, ano, cd_editora, cd_genero, preco = livro
    print("Pressione Enter para manter o valor entre colchetes.")
    titulo = ler_texto("Título", titulo, 100)
    autor = ler_texto("Autor", autor, 50)
    ano = ler_numero("Ano de publicação", ano, 1000, 2100, opcional=True)
    cd_editora = escolher_codigo(conn, "editora", "Editora", cd_editora)
    cd_genero = escolher_codigo(conn, "genero", "Gênero", cd_genero)
    if cd_editora is None or cd_genero is None:
        return
    preco = ler_preco(preco)
    banco.alterar_livro(conn, isbn, titulo, autor, ano, cd_editora, cd_genero, preco)
    print("Livro alterado.")

def excluir_livro(conn):
    print("\n== EXCLUSÃO DE LIVRO ==")
    isbn = ler_numero("ISBN do livro", minimo=1)
    livro = banco.livro_por_isbn(conn, isbn)
    if not livro:
        print("Livro não encontrado.")
        return
    mostrar_livros(livro)
    if input("Confirma a exclusão? (s/n): ").strip().lower() == "s":
        banco.excluir_livro(conn, isbn)
        print("Livro excluído.")
    else:
        print("Exclusão cancelada.")

def consultar_livros(conn):
    print("\n== CONSULTA DE LIVROS ==")
    print("1. Listar todos\n2. Por ISBN\n3. Por título ou autor\n4. Por gênero\n5. Por editora")
    op = input("Escolha: ").strip()
    if op == "1":
        mostrar_livros(banco.listar_livros(conn))
    elif op == "2":
        mostrar_livros(banco.livro_por_isbn(conn, ler_numero("ISBN", minimo=1)))
    elif op == "3":
        mostrar_livros(banco.livros_por_texto(conn, input("Termo: ").strip()))
    elif op == "4":
        cod = escolher_codigo(conn, "genero", "Gênero")
        mostrar_livros(banco.livros_por_genero(conn, cod) if cod else [])
    elif op == "5":
        cod = escolher_codigo(conn, "editora", "Editora")
        mostrar_livros(banco.livros_por_editora(conn, cod) if cod else [])
    else:
        print("Opção inválida.")

def incluir_simples(conn, tab, rotulo):
    print(f"\n== INCLUSÃO – {rotulo.upper()} ==")
    codigo = banco.proximo_codigo(conn, tab)
    nome = ler_texto(rotulo, maximo=banco.TABELAS[tab][3])
    banco.incluir_simples(conn, tab, codigo, nome)
    print(f"Registro incluído com o código {codigo}.")


def alterar_simples(conn, tab, rotulo):
    print(f"\n== ALTERAÇÃO – {rotulo.upper()} ==")
    reg = banco.buscar_simples(conn, tab, ler_numero("Código", minimo=1))
    if not reg:
        print("Registro não encontrado.")
        return
    nome = ler_texto(rotulo, reg[1], banco.TABELAS[tab][3])
    banco.alterar_simples(conn, tab, reg[0], nome)
    print("Registro alterado.")


def excluir_simples(conn, tab, rotulo):
    print(f"\n== EXCLUSÃO – {rotulo.upper()} ==")
    reg = banco.buscar_simples(conn, tab, ler_numero("Código", minimo=1))
    if not reg:
        print("Registro não encontrado.")
        return
    mostrar_simples([reg], rotulo)
    if input("Confirma a exclusão? (s/n): ").strip().lower() != "s":
        print("Exclusão cancelada.")
        return
    try:
        banco.excluir_simples(conn, tab, reg[0])
        print("Registro excluído.")
    except IntegrityError:
        print("Não é possível excluir: existem livros vinculados a este registro.")


def consultar_simples(conn, tab, rotulo):
    print(f"\n== CONSULTA – {rotulo.upper()} ==\n1. Listar todos\n2. Por código\n3. Por nome")
    op = input("Escolha: ").strip()
    if op == "1":
        mostrar_simples(banco.listar_simples(conn, tab), rotulo)
    elif op == "2":
        reg = banco.buscar_simples(conn, tab, ler_numero("Código", minimo=1))
        mostrar_simples([reg] if reg else [], rotulo)
    elif op == "3":
        mostrar_simples(banco.buscar_simples_nome(conn, tab, input("Termo: ").strip()), rotulo)
    else:
        print("Opção inválida.")


# ---------- menus ----------
def submenu(titulo, ops):
    while True:
        print(f"\n--- {titulo} ---\n1. Inclusão\n2. Alteração\n3. Exclusão\n4. Consulta\n0. Voltar")
        op = input("Escolha: ").strip()
        if op == "0":
            return
        if op not in ops:
            print("Opção inválida.")
            continue
        try:
            ops[op]()
        except Error as e:
            print(f"Erro no banco de dados: {e}")


def menu():
    with closing(banco.conectar()) as conn:
        def ops(tab, rotulo):
            return {"1": lambda: incluir_simples(conn, tab, rotulo), "2": lambda: alterar_simples(conn, tab, rotulo),
                    "3": lambda: excluir_simples(conn, tab, rotulo), "4": lambda: consultar_simples(conn, tab, rotulo)}
        livros = {"1": lambda: incluir_livro(conn), "2": lambda: alterar_livro(conn),
                  "3": lambda: excluir_livro(conn), "4": lambda: consultar_livros(conn)}
        telas = {"1": ("Livros", livros), "2": ("Gêneros", ops("genero", "Gênero")),
                 "3": ("Editoras", ops("editora", "Editora"))}
        while True:
            print("\n===== OpenShelf – Cadastro =====\n1. Livros\n2. Gêneros\n3. Editoras\n0. Sair")
            op = input("Escolha uma opção: ").strip()
            if op == "0":
                print("Até logo!")
                return
            if op in telas:
                submenu(*telas[op])
            else:
                print("Opção inválida.")


if __name__ == "__main__":
    try:
        menu()
    except (KeyboardInterrupt, EOFError):
        print("\nEncerrado.")
    except Error as e:
        print(f"\nNão foi possível usar o MySQL: {e}\nConfira se o servidor está ligado e o usuário/senha (DB_USER, DB_PASSWORD).")