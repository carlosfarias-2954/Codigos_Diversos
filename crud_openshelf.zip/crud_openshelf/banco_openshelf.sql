-- criar o comando ddl e dml bd_openshelf
-- 21-11-2026

create database bd_openshelf default character set utf8mb4;
use bd_openshelf;

create table tb_genero
(cd_genero int not null primary key,
genero char(40));

create table tb_editora
(cd_editora int not null primary key,
editora char(30));

create table tb_livro
(isbn bigint not null primary key,
titulo char(100),
autor char(50),
ano int,
cd_editora int,
cd_genero int,
preco decimal(12,2));

alter table tb_livro
add constraint fk_editora foreign key (cd_editora)
references tb_editora (cd_editora);

alter table tb_livro
add constraint fk_genero foreign key (cd_genero)
references tb_genero (cd_genero);

-- dados iniciais (acervo do OpenShelf)

insert into tb_genero values
(1, 'Artes e disciplinas da linguagem'),
(2, 'Ciência'),
(3, 'Design'),
(4, 'Direito'),
(5, 'Economia de negócios'),
(6, 'Ficção'),
(7, 'História'),
(8, 'Medicina e saúde');

insert into tb_editora values
(1, 'Pearson'),
(2, 'Não informada');

-- os isbn abaixo sao codigos de exemplo para teste, troque pelos reais depois
insert into tb_livro values
(1001, 'Sustentabilidade: gestão estratégica na prática', 'Sonia Lopes e outro(s)', null, 2, 5, null),
(1002, 'Histologia', 'Gentileza Santos Martins Neiva', null, 1, 8, null),
(1003, 'Fundamentos de administração', 'Filipe Sobral e outro(s)', null, 1, 5, null),
(1004, 'Análise das demonstrações contábeis', 'Samir Bazzi', null, 1, 5, null),
(1005, 'Química: a ciência central', 'Theodore L. Brown e outro(s)', null, 1, 2, null),
(1006, 'Reinventando a liderança', 'Renata Di Nizo', null, 2, 5, null),
(1007, 'Ensino jurídico: do império à contemporaneidade', 'Cleyson de Moraes Mello', null, 2, 4, null),
(1008, '10 anos de vigência do estatuto da pessoa com deficiência', 'Heloisa Helena Barboza e outro(s)', null, 2, 4, null),
(1009, 'Eca digital: estatuto digital da criança e do adolescente', 'Marcia Ignácio', null, 2, 4, null),
(1010, 'Técnica de sentença penal descomplicada para concursos', 'Daniel Konder de Almeida', null, 2, 4, null),
(1011, 'Justiça, cidades e infâncias: limites e desafios', 'Daniel Konder de Almeida', null, 2, 4, null),
(1012, 'Ana Karenina', 'Liev Tolstói e outro(s)', 1877, 2, 6, null),
(1013, 'Nova gramática do português contemporâneo', 'Celso Cunha e outro(s)', null, 2, 1, null),
(1014, 'Fiódor Dostoiévski: obra completa', 'Fiódor Dostoiévski', null, 2, 6, null),
(1015, 'Livros históricos', 'Flavio Dalla Vecchia', null, 2, 7, null),
(1016, 'Legal design: visual law, design thinking', 'Alexandre Zavaglia Coelho e outro(s)', null, 2, 3, null);

-- comandos do crud (executados pelo banco.py, %s e preenchido pelo python)

-- inclusao
-- insert into tb_livro (isbn, titulo, autor, ano, cd_editora, cd_genero, preco) values (%s, %s, %s, %s, %s, %s, %s)
-- insert into tb_genero (cd_genero, genero) values (%s, %s)
-- insert into tb_editora (cd_editora, editora) values (%s, %s)

-- alteracao
-- update tb_livro set titulo = %s, autor = %s, ano = %s, cd_editora = %s, cd_genero = %s, preco = %s where isbn = %s
-- update tb_genero set genero = %s where cd_genero = %s
-- update tb_editora set editora = %s where cd_editora = %s

-- exclusao
-- delete from tb_livro where isbn = %s
-- delete from tb_genero where cd_genero = %s
-- delete from tb_editora where cd_editora = %s

-- consulta
-- select l.isbn, l.titulo, l.autor, l.ano, e.editora, g.genero, l.preco
-- from tb_livro l
-- left join tb_editora e on e.cd_editora = l.cd_editora
-- left join tb_genero g on g.cd_genero = l.cd_genero
-- order by l.titulo
