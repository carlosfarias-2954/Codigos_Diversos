import getpass
import os
import sys
from pathlib import Path

try:
    import mysql.connector
    from mysql.connector import Error, IntegrityError
except ImportError as erro:
    sys.exit(
        "Driver do MySQL não encontrado.\n"
        f"Python em uso: {sys.executable}\n"
        f"Detalhe: {erro}\n"
        "Instale no MESMO Python com:\n"
        f'  "{sys.executable}" -m pip install mysql-connector-python'
    )

BASE = Path(__file__).parent
SQL_PATH = BASE / "banco_openshelf.sql"
NOME_BANCO = "bd_openshelf"

CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD"),
    "charset": "utf8mb4",
}

# tabela, coluna do código, coluna do nome e tamanho máximo do nome
TABELAS = {
    "genero": ("tb_genero", "cd_genero", "genero", 40),
    "editora": ("tb_editora", "cd_editora", "editora", 30),
}

SELECT_LIVRO = """select l.isbn, l.titulo, l.autor, l.ano, e.editora, g.genero, l.preco
                  from tb_livro l
                  left join tb_editora e on e.cd_editora = l.cd_editora
                  left join tb_genero g on g.cd_genero = l.cd_genero"""


# ---------- conexão ----------
def comandos_sql(caminho=SQL_PATH):
    """Lê o arquivo .sql, ignora os comentários e devolve a lista de comandos."""
    linhas = [l.split("--")[0] for l in caminho.read_text(encoding="utf-8").splitlines()]
    return [c.strip() for c in "\n".join(linhas).split(";") if c.strip()]


def conectar():
    """Conecta ao MySQL. Se o bd_openshelf não existir, cria tudo com o banco_openshelf.sql."""
    if CONFIG["password"] is None:
        CONFIG["password"] = getpass.getpass(f"Senha do MySQL (usuário {CONFIG['user']}): ")
    conn = mysql.connector.connect(**CONFIG)
    cur = conn.cursor()
    cur.execute("show databases like %s", (NOME_BANCO,))
    if cur.fetchone() is None:
        print(f"Banco {NOME_BANCO} não encontrado. Criando a partir do {SQL_PATH.name}...")
        for comando in comandos_sql():
            cur.execute(comando)
        conn.commit()
    cur.execute(f"use {NOME_BANCO}")
    cur.close()
    return conn


def _ler(conn, sql, params=()):
    cur = conn.cursor()
    try:
        cur.execute(sql, params)
        return cur.fetchall()
    finally:
        cur.close()


def _escrever(conn, sql, params=()):
    cur = conn.cursor()
    try:
        cur.execute(sql, params)
        conn.commit()
    except Error:
        conn.rollback()
        raise
    finally:
        cur.close()


# ---------- gêneros e editoras ----------
def proximo_codigo(conn, tab):
    _, cd, _, _ = TABELAS[tab]
    return _ler(conn, f"select coalesce(max({cd}), 0) + 1 from {TABELAS[tab][0]}")[0][0]


def incluir_simples(conn, tab, codigo, nome):
    t, cd, nm, _ = TABELAS[tab]
    _escrever(conn, f"insert into {t} ({cd}, {nm}) values (%s, %s)", (codigo, nome))


def alterar_simples(conn, tab, codigo, nome):
    t, cd, nm, _ = TABELAS[tab]
    _escrever(conn, f"update {t} set {nm} = %s where {cd} = %s", (nome, codigo))


def excluir_simples(conn, tab, codigo):
    t, cd, _, _ = TABELAS[tab]
    _escrever(conn, f"delete from {t} where {cd} = %s", (codigo,))


def listar_simples(conn, tab):
    t, cd, nm, _ = TABELAS[tab]
    return _ler(conn, f"select {cd}, {nm} from {t} order by {nm}")


def buscar_simples(conn, tab, codigo):
    t, cd, nm, _ = TABELAS[tab]
    linhas = _ler(conn, f"select {cd}, {nm} from {t} where {cd} = %s", (codigo,))
    return linhas[0] if linhas else None


def buscar_simples_nome(conn, tab, termo):
    t, cd, nm, _ = TABELAS[tab]
    return _ler(conn, f"select {cd}, {nm} from {t} where {nm} like %s order by {nm}", (f"%{termo}%",))


# ---------- livros ----------
def incluir_livro(conn, isbn, titulo, autor, ano, cd_editora, cd_genero, preco):
    _escrever(
        conn,
        "insert into tb_livro (isbn, titulo, autor, ano, cd_editora, cd_genero, preco) "
        "values (%s, %s, %s, %s, %s, %s, %s)",
        (isbn, titulo, autor, ano, cd_editora, cd_genero, preco),
    )


def alterar_livro(conn, isbn, titulo, autor, ano, cd_editora, cd_genero, preco):
    _escrever(
        conn,
        "update tb_livro set titulo = %s, autor = %s, ano = %s, cd_editora = %s, "
        "cd_genero = %s, preco = %s where isbn = %s",
        (titulo, autor, ano, cd_editora, cd_genero, preco, isbn),
    )


def excluir_livro(conn, isbn):
    _escrever(conn, "delete from tb_livro where isbn = %s", (isbn,))


def buscar_livro(conn, isbn):
    """Registro puro da tabela (com os códigos), usado na alteração."""
    linhas = _ler(
        conn,
        "select isbn, titulo, autor, ano, cd_editora, cd_genero, preco from tb_livro where isbn = %s",
        (isbn,),
    )
    return linhas[0] if linhas else None


def listar_livros(conn):
    return _ler(conn, SELECT_LIVRO + " order by l.titulo")


def livro_por_isbn(conn, isbn):
    return _ler(conn, SELECT_LIVRO + " where l.isbn = %s", (isbn,))


def livros_por_texto(conn, termo):
    p = f"%{termo}%"
    return _ler(conn, SELECT_LIVRO + " where l.titulo like %s or l.autor like %s order by l.titulo", (p, p))


def livros_por_genero(conn, cd_genero):
    return _ler(conn, SELECT_LIVRO + " where l.cd_genero = %s order by l.titulo", (cd_genero,))


def livros_por_editora(conn, cd_editora):
    return _ler(conn, SELECT_LIVRO + " where l.cd_editora = %s order by l.titulo", (cd_editora,))